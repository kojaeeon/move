Microsoft Visual C++ v14 Redistributable (x64)
Product version: 14.51.36247.0
Downloaded (UTC): 2026-11-07T06:26:36Z
Official source: https://aka.ms/vc14/vc_redist.x64.exe
Documentation: https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist
SHA-256 (VC_redist.x64.exe): 843068991daaa1f73ad9f6239bce4d0f6a07a51f18c37ea2a867e9beca71295c
Authenticode: Valid
Publisher: CN=Microsoft Corporation, O=Microsoft Corporation, L=Redmond, S=Washington, C=US

Extract the ZIP and run VC_redist.x64.exe on the target Windows PC.
