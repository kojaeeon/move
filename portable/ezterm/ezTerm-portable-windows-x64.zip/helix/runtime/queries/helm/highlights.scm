; inherits: gotmpl
