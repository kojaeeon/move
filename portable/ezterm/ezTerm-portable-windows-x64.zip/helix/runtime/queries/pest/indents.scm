[
  (expression)
] @indent

[
  "]"
  "}"
  ")"
] @outdent
