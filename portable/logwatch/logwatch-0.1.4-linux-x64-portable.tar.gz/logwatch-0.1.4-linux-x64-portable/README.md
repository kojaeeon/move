# Logwatch 0.1.4 — Linux x86-64

압축을 푼 폴더에서 실행하세요.

~~~bash
./logwatch --dump ./logs/application.log
./logwatch /path/to/application.log
~~~

SSH 터미널에서 x는 XML 보기, v는 원문 보기, q는 종료입니다.
y는 서버의 Wayland(xclip 대신 wl-copy 사용) 또는 X11(xclip) 클립보드를 사용합니다.
일반 SSH 접속에서는 PC 클립보드로 복사할 때 터미널의 복사 기능을 사용하세요.

[소스 및 사용 가이드](https://github.com/kojaeeon/rust_toy/tree/5927cb54fa6f79069e90ae37916472058d9918ca/logwatch)
