# Hotkeys for Windows x64

`hotkeys.toml`과 같은 폴더에 둔 `hotkeys.exe`를 실행하세요. 설치 과정 없이 알림 영역에서 동작합니다.
아이콘이 보이지 않으면 작업 표시줄의 숨겨진 아이콘을 펼치세요.
아이콘을 우클릭하고 **Exit**를 선택하면 단축키 등록이 해제됩니다.

| 기본 단축키 | 동작 |
|---|---|
| Ctrl+Alt+1 | 현재 입력창에 `SELECT * FROM ` 입력 |
| Ctrl+Alt+2 | F5 전송 |
| Ctrl+Alt+3 | Ctrl+Shift+F 전송 |

`hotkeys.exe` 옆의 `hotkeys.toml`을 UTF-8로 편집하고 프로그램을 재시작하면
변경된 설정을 읽습니다. 각 항목에 `text`, `send`, `exe` 중 하나를 지정하세요.

```toml
[[hotkeys]]
trigger = "Ctrl+Alt+4"
text = "조회 완료"

[[hotkeys]]
trigger = "Ctrl+Alt+5"
send = "Ctrl+Enter"

[[hotkeys]]
trigger = "Ctrl+Alt+6"
exe = 'C:\Portable\OpenIDEA\openidea.exe'
```

포터블 앱을 먼저 압축 해제하고 `exe`에 실행 파일을 지정하세요. Windows 경로를 작은따옴표로 감싸면 백슬래시를 그대로 쓸 수 있습니다. 상대 경로는 `hotkeys.toml`이 있는 폴더를 기준으로 해석하며, 작업 폴더는 EXE가 있는 폴더입니다.

트리거에는 Ctrl, Alt, Shift, Win 중 하나 이상을 붙입니다. 문자 A–Z, 숫자 0–9,
F1–F24, Tab, Enter, Space, Esc, Backspace, 방향키, Home, End, PageUp,
PageDown, Insert, Delete를 지정할 수 있습니다. Windows가 예약한 F12는 트리거에
쓸 수 없습니다. Windows나 다른 프로그램이 이미 트리거를 등록한 경우 시작 시
해당 조합을 표시합니다.

`text`와 `send`는 단축키를 놓으면 포커스가 있는 창에 입력합니다. 대기 중 창이 바뀌면 그 입력을
취소합니다. Windows의 입력 권한 제한 때문에 일반 권한으로 실행한 Hotkeys는
관리자 권한으로 실행 중인 앱에 입력을 보낼 수 없습니다.

## 트레이 아이콘

기본 아이콘은 **키캡 + 번개(1번 시안)**이며 EXE에 내장되어 있습니다.
별도 파일이 없어도 동작하며 16~256px 프레임으로 작은 트레이와 고해상도 화면을 지원합니다.

다른 아이콘을 쓰려면 `hotkeys.toml`의 **첫 번째 `[[hotkeys]]` 앞**에 설정하세요.

```toml
[tray]
icon = 'icons\my-hotkey.ico'

[[hotkeys]]
trigger = 'Ctrl+Alt+1'
text = 'SELECT * FROM '
```

절대 경로도 사용할 수 있습니다. 상대 경로는 `hotkeys.toml` 위치 기준이며
Windows 경로는 작은따옴표로 감싸세요. 파일 형식은 `.ico`입니다.
설정을 생략하거나 `icon`을 지우거나 빈 문자열로 두면 기본 아이콘을 사용합니다.
파일이 없거나 로드할 수 없으면 경고 후 내장 아이콘으로 실행합니다.
설정 변경 후 프로그램을 재시작하세요. Explorer가 재시작돼도 같은 아이콘을 복원합니다.
이 설정은 알림 영역 아이콘에 적용되며 탐색기의 EXE 파일 아이콘을 바꾸지는 않습니다.

원본 도형은 `assets/hotkeys.svg`, 내장 파일은 `assets/hotkeys.ico`입니다.
재생성은 개발 환경에서 `pip install Pillow CairoSVG` 후
`python scripts/generate_tray_icon.py`로 수행합니다. 배포 PC에는 Python이 필요 없습니다.

## 소스 빌드

Windows x64에서 저장소의 `hotkey` 폴더로 이동한 뒤 PowerShell에서 실행하세요.

```powershell
cargo test --locked
cargo build --locked --release --target x86_64-pc-windows-msvc
Copy-Item ./hotkeys.toml ./target/x86_64-pc-windows-msvc/release/
./target/x86_64-pc-windows-msvc/release/hotkeys.exe
```
