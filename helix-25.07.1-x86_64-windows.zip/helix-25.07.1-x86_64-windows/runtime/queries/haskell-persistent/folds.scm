[
 (entity_definition)
] @fold
