; inherits: xml
